# country_code_endonym_map 

Map of country codes to their native preferred endonym in json format