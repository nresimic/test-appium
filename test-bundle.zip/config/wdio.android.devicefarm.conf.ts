import path from 'path';
import { config as sharedConfig } from './wdio.shared.conf';
import type { Options } from '@wdio/types';

function getDeviceFarmAppPath(): string {
    const deviceFarmAppPath = process.env.DEVICEFARM_APP_PATH;
    
    if (deviceFarmAppPath) {
        console.log(`Using Device Farm app path: ${deviceFarmAppPath}`);
        return deviceFarmAppPath;
    }
    
    console.warn('DEVICEFARM_APP_PATH not found, using local fallback');
    return path.join(__dirname, '..', 'apps', 'android', 'app-UAE-main-build-52.apk');
}

export const config = {
    ...sharedConfig,
    port: 4723,
    specs: [
        '../test/e2e/**/*.e2e.ts'
    ],
    reporters: [
        'spec',
        ['allure', {
            outputDir: 'allure-results',
            disableWebdriverStepsReporting: true, // Hide noisy WebDriver step names
            disableWebdriverScreenshotsReporting: true, // Disable automatic screenshots to prevent duplicates
            useCucumberStepReporter: false,
            addConsoleLogs: true,
            // This will still capture WebDriver commands as attachments to your custom steps
            disableMochaHooks: false
        }]
    ],
    // Device Farm specific capabilities
    capabilities: [{
        platformName: 'Android',
        // Use Device Farm provided device info
        'appium:platformVersion': process.env.DEVICEFARM_DEVICE_OS_VERSION || process.env.ANDROID_VERSION,
        'appium:deviceName': process.env.DEVICEFARM_DEVICE_NAME || 'Android Device',
        'appium:udid': process.env.DEVICEFARM_DEVICE_UDID,
        // Use Device Farm app path
        'appium:app': getDeviceFarmAppPath(),
        'appium:automationName': 'UiAutomator2',
        'appium:noReset': false,
        'appium:fullReset': false,
        'appium:newCommandTimeout': 300,
        // Device Farm specific settings with adaptive timeouts
        'appium:appWaitForLaunch': true,
        'appium:appWaitDuration': 45000,
        'appium:androidInstallTimeout': 120000,
        'appium:uiautomator2ServerInstallTimeout': 120000,
        // Enhanced stability settings
        'appium:skipServerInstallation': false,
        'appium:skipDeviceInitialization': false,
        'appium:disableWindowAnimation': true 
    }],
    
    autoCompileOpts: {
        autoCompile: true,
        tsNodeOpts: {
            transpileOnly: true
        }
    },
    
    onPrepare: function () {
        console.log('=== Device Farm Android Configuration ===');
        console.log('Device Name:', process.env.DEVICEFARM_DEVICE_NAME);
        console.log('Platform:', process.env.DEVICEFARM_DEVICE_PLATFORM_NAME);
        console.log('OS Version:', process.env.DEVICEFARM_DEVICE_OS_VERSION);
        console.log('App Path:', process.env.DEVICEFARM_APP_PATH);
        console.log('UDID:', process.env.DEVICEFARM_DEVICE_UDID);
        
        // Set Device Farm environment variables for adaptive behavior
        process.env.PARALLEL_MODE = 'true';
        process.env.DEVICEFARM_ENVIRONMENT = 'true';
        
        // Detect potential performance constraints
        const deviceName = process.env.DEVICEFARM_DEVICE_NAME?.toLowerCase();
        const osVersion = process.env.DEVICEFARM_DEVICE_OS_VERSION;
        
        // Flag slower devices or older OS versions
        if (deviceName && (deviceName.includes('s8') || deviceName.includes('s9') || 
                          deviceName.includes('pixel 3') || deviceName.includes('pixel 4'))) {
            process.env.DEVICEFARM_SLOWER_DEVICE = 'true';
            console.log('🐢 Slower device detected - enabling enhanced timeouts');
        }
        
        if (osVersion && parseInt(osVersion) < 11) {
            process.env.DEVICEFARM_OLDER_OS = 'true';
            console.log('📅 Older Android version detected - enabling compatibility mode');
        }
        
        // Set timeout multiplier based on device characteristics
        let timeoutMultiplier = 1.8; // Base Device Farm multiplier
        if (process.env.DEVICEFARM_SLOWER_DEVICE) timeoutMultiplier *= 1.3;
        if (process.env.DEVICEFARM_OLDER_OS) timeoutMultiplier *= 1.2;
        
        process.env.TIMEOUT_MULTIPLIER = timeoutMultiplier.toString();
        
        console.log('🔀 Device Farm parallel mode enabled - using unique users per device');
        console.log(`⏱️ Timeout multiplier set to: ${timeoutMultiplier}x`);
    },
    
    beforeSuite: function (_suite) {
        // addEnvironment is deprecated in newer versions of @wdio/allure-reporter
        // Use reportedEnvironmentVars in reporter config instead
    }
} as Options.Testrunner;