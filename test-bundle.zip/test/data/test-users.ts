import { faker } from '@faker-js/faker';

export interface TestUser {
    phoneNumber: string;
    otp: string;
    passcode: string;
    firstName: string;
    lastName: string;
    email: string;
}

/**
 * Generate a valid UAE phone number for testing
 * UAE mobile numbers: 50/52/54/55/56/58 + 7 digits (total 9 digits)
 * Using 50XXXXXXX format
 */
function generateTestPhoneNumber(): string {
    const prefix = faker.helpers.arrayElement(['50', '52', '54', '55', '56', '58']);
    const middlePart = faker.number.int({ min: 100, max: 999 });
    const lastPart = faker.number.int({ min: 1000, max: 9999 });
    return `${prefix}${middlePart}${lastPart}`;
}

export const TestUsers = {
    // Pool of existing users for parallel execution
    userPool: [
        {
            phoneNumber: '500990227',
            otp: '0000',
            passcode: '0000',
            firstName: 'Test',
            lastName: 'User',
            email: 'testonebewe.user@example.com'
        },
        {
            phoneNumber: '554595453',
            otp: '0000',
            passcode: '0000',
            firstName: 'John',
            lastName: 'Doe',
            email: 'john.doe.test@example.com'
        },
        {
            phoneNumber: '561234567',
            otp: '0000',
            passcode: '0000',
            firstName: 'Alice',
            lastName: 'Smith',
            email: 'alice.smith@example.com'
        },
        {
            phoneNumber: '509876543',
            otp: '0000',
            passcode: '0000',
            firstName: 'Bob',
            lastName: 'Johnson',
            email: 'bob.johnson@example.com'
        },
        {
            phoneNumber: '523456789',
            otp: '0000',
            passcode: '0000',
            firstName: 'Carol',
            lastName: 'Williams',
            email: 'carol.williams@example.com'
        }
    ] as TestUser[],
    
    // Dynamic user assignment for parallel execution
    getUniqueUser(): TestUser {
        const sessionId = browser.sessionId || 'default';
        const deviceName = (browser.capabilities as any)['appium:deviceName'] || '';
        
        // Create a hash based on session + device for consistent user assignment
        const hash = this.simpleHash(sessionId + deviceName);
        const userIndex = hash % this.userPool.length;
        
        const assignedUser = this.userPool[userIndex];
        console.log(`👤 Assigned user ${assignedUser.phoneNumber} to device ${deviceName} (session: ${sessionId.slice(-8)})`);
        
        return assignedUser;
    },
    
    // Simple hash function for consistent user assignment
    simpleHash(str: string): number {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash);
    },
    
    // Legacy fixed users (keep for backward compatibility)
    userWithBankAccount: {
        phoneNumber: '500990227',
        otp: '0000',
        passcode: '0000',
        firstName: 'Test',
        lastName: 'User',
        email: 'testonebewe.user@example.com'
    } as TestUser,
    
    userWithoutBankAccount: {
        phoneNumber: '554595453',
        otp: '0000',
        passcode: '0000',
        firstName: 'John',
        lastName: 'Doe',
        email: 'john.doe.test@example.com'
    } as TestUser,
    
    // Smart getters for parallel execution compatibility
    get validUserWithBankAcc() {
        // Use unique user for parallel execution, fallback to fixed for single
        const isParallel = Boolean((browser.capabilities as any)?.maxInstances > 1 || process.env.PARALLEL_MODE);
        return isParallel ? this.getUniqueUser() : this.userWithBankAccount;
    },
    
    get validUserWithoutBankAcc() {
        // Use unique user for parallel execution, fallback to fixed for single
        const isParallel = Boolean((browser.capabilities as any)?.maxInstances > 1 || process.env.PARALLEL_MODE);
        return isParallel ? this.getUniqueUser() : this.userWithoutBankAccount;
    },
    
    // Generate new user for registration tests
    generateNewUser(): TestUser {
        const firstName = faker.person.firstName();
        const lastName = faker.person.lastName();
        const uniqueId = Date.now();
        
        return {
            phoneNumber: generateTestPhoneNumber(),
            otp: '0000',
            passcode: '0000',
            firstName,
            lastName,
            email: faker.internet.email({ 
                firstName: firstName.toLowerCase(),
                lastName: `${lastName.toLowerCase()}.${uniqueId}`,
                provider: 'testapp.com'
            })
        };
    },
    
    // Get a new user instance (cached per test run)
    get newUser(): TestUser {
        if (!this._cachedNewUser) {
            this._cachedNewUser = this.generateNewUser();
        }
        return this._cachedNewUser;
    },
    
    // Private cached user
    _cachedNewUser: null as TestUser | null,
    
    // Invalid user for negative tests
    invalidUser: {
        phoneNumber: '000000000',
        otp: '9999',
        passcode: '1234',
        firstName: faker.person.firstName(),
        lastName: faker.person.lastName(),
        email: faker.internet.email()
    } as TestUser
};