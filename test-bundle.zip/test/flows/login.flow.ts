import WelcomeScreen from '../screens/auth/welcome.screen';
import AuthScreen from '../screens/auth/auth.screen';
import LinkBankScreen from '../screens/link-bank.screen';
// import DashboardScreen from '../screens/dashboard.screen';
import { TestUser } from '../data/test-users';
import BottomNavigationScreen from '../screens/navigation/bottom-navigation.screen';
import { smartWait, TIMEOUTS } from '../utils/wait.utils';

export class LoginFlow {
    
    static async login(user: TestUser) {

        await WelcomeScreen.waitForScreen();
        
        await WelcomeScreen.tapLoginButton();
        
        await AuthScreen.performLogin(user);

        await this.waitForPostLoginScreen();
    }
    
    /**
     * Wait for either Dashboard or Link Bank screen to appear after login
     * Handles whichever appears
     */
    private static async waitForPostLoginScreen() {
        console.log('⏳ Waiting for post-login screen (Dashboard or Link Bank)...');
        
        // Use smartWait with condition instead of manual while loop
        await smartWait(
            async () => {
                // Check both in parallel
                const [isDashboardVisible, isLinkBankVisible] = await Promise.all([
                    BottomNavigationScreen.dashboardButton.isDisplayed().catch(() => false),
                    LinkBankScreen.maybeLaterButton.isDisplayed().catch(() => false)
                ]);
                
                // Dashboard appeared - we're done!
                if (isDashboardVisible) {
                    console.log('✅ Dashboard displayed - login complete');
                    return true;
                }
                
                // Link Bank appeared - skip it and wait for dashboard
                if (isLinkBankVisible) {
                    console.log('🏦 Link Bank screen appeared - skipping...');
                    await LinkBankScreen.skipBankLinking();
                    
                    // Now wait for dashboard
                    await BottomNavigationScreen.dashboardButton.waitForDisplayed({
                        timeout: TIMEOUTS.STANDARD,
                        timeoutMsg: 'Dashboard not displayed after skipping Link Bank'
                    });
                    return true;
                }
                
                // Neither found yet
                return false;
            },
            {
                timeout: TIMEOUTS.LOGIN,  // Use our defined LOGIN timeout
                interval: TIMEOUTS.POLLING_INTERVAL,
                message: 'Login failed: Neither Dashboard nor Link Bank screen appeared'
            }
        );
    }
    static async navigateToLoginScreen() {
        await WelcomeScreen.waitForScreen();
        await WelcomeScreen.tapLoginButton();
    }

    /**
     * Quick login for re-login after logout
     * Uses performQuickLogin which handles the different passcode flow
     */
    static async quickLogin(user: TestUser) {
        await WelcomeScreen.waitForScreen();
        await WelcomeScreen.tapLoginButton();
        await AuthScreen.performQuickLogin(user);
        
        // Use the same post-login screen handling
        await this.waitForPostLoginScreen();
    }
}