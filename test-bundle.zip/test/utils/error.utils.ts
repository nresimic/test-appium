export class TestError extends Error {
    constructor(
        message: string,
        public readonly context?: Record<string, unknown>,
        public readonly recoverable: boolean = false
    ) {
        super(message);
        this.name = 'TestError';
    }
}

export class ElementNotFoundError extends TestError {
    constructor(selector: string, timeout?: number, isDeviceFarm?: boolean) {
        const envInfo = isDeviceFarm ? ' (Device Farm)' : '';
        const message = timeout 
            ? `Element not found: ${selector} after ${timeout}ms${envInfo}`
            : `Element not found: ${selector}${envInfo}`;
        super(message, { selector, timeout, isDeviceFarm }, false);
        this.name = 'ElementNotFoundError';
    }
}

export class TimeoutError extends TestError {
    constructor(operation: string, timeout: number) {
        super(`Operation timed out: ${operation} after ${timeout}ms`, { operation, timeout }, true);
        this.name = 'TimeoutError';
    }
}

export class ValidationError extends TestError {
    constructor(expected: unknown, actual: unknown, field?: string) {
        const fieldStr = field ? ` for ${field}` : '';
        super(`Validation failed${fieldStr}. Expected: ${expected}, Got: ${actual}`, { expected, actual, field }, false);
        this.name = 'ValidationError';
    }
}

export async function withErrorHandling<T>(
    operation: () => Promise<T>,
    errorContext: {
        operation: string;
        recoverable?: boolean;
        onError?: (error: Error) => Promise<void>;
        fallback?: () => Promise<T>;
        maxRetries?: number;
        retryDelay?: number;
        deviceFarmAware?: boolean;
    }
): Promise<T> {
    const { 
        maxRetries = 1, 
        retryDelay = 1000, 
        deviceFarmAware = true 
    } = errorContext;
    
    const isDeviceFarm = deviceFarmAware && isDeviceFarmEnvironment();
    const actualRetries = isDeviceFarm ? Math.max(maxRetries, 2) : maxRetries;
    const actualDelay = isDeviceFarm ? retryDelay * 1.5 : retryDelay;
    
    let lastError: TestError;
    
    for (let attempt = 1; attempt <= actualRetries; attempt++) {
        try {
            if (attempt > 1) {
                const envInfo = isDeviceFarm ? ' (Device Farm)' : '';
                console.log(`🔄 Retry ${attempt}/${actualRetries} for: ${errorContext.operation}${envInfo}`);
                await new Promise(resolve => setTimeout(resolve, actualDelay * attempt));
            }
            
            return await operation();
        } catch (error) {
            lastError = error instanceof TestError 
                ? error 
                : new TestError(
                    `${errorContext.operation} failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
                    { 
                        originalError: error, 
                        attempt, 
                        maxRetries: actualRetries,
                        isDeviceFarm 
                    },
                    errorContext.recoverable ?? false
                );

            if (errorContext.onError) {
                await errorContext.onError(lastError);
            }
            
            if (attempt === actualRetries) {
                break;
            }
        }
    }

    if (errorContext.fallback && lastError!.recoverable) {
        console.log(`🔄 Attempting fallback for: ${errorContext.operation}`);
        return await errorContext.fallback();
    }

    throw lastError!;
}

export function isDeviceFarmEnvironment(): boolean {
    return !!(process.env.DEVICEFARM_DEVICE_UDID || process.env.PARALLEL_MODE);
}

export function logError(error: Error, context?: Record<string, unknown>) {
    const timestamp = new Date().toISOString();
    const contextStr = context ? ` | Context: ${JSON.stringify(context)}` : '';
    console.error(`[${timestamp}] ❌ ${error.name}: ${error.message}${contextStr}`);
    
    if (error instanceof TestError && error.context) {
        console.error(`[${timestamp}] 📋 Error Context:`, error.context);
    }
}

export function isRecoverableError(error: Error): boolean {
    return error instanceof TestError && error.recoverable;
}

export async function safeOperation<T>(
    operation: () => Promise<T>,
    fallback?: T,
    options: {
        logAsWarning?: boolean;
        deviceFarmRetry?: boolean;
        retryDelay?: number;
    } = {}
): Promise<T | undefined> {
    const { logAsWarning = true, deviceFarmRetry = true, retryDelay = 500 } = options;
    const maxAttempts = deviceFarmRetry && isDeviceFarmEnvironment() ? 2 : 1;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
            if (attempt > 1) {
                await new Promise(resolve => setTimeout(resolve, retryDelay));
            }
            return await operation();
        } catch (error) {
            if (attempt === maxAttempts) {
                if (logAsWarning) {
                    const envInfo = isDeviceFarmEnvironment() ? ' (Device Farm)' : '';
                    console.warn(`⚠️ Safe operation failed after ${attempt} attempts: ${error instanceof Error ? error.message : 'Unknown error'}${envInfo}`);
                }
                return fallback;
            }
        }
    }
    return fallback;
}

export async function withElementRetry<T>(
    elementGetter: () => WebdriverIO.Element,
    operation: (element: WebdriverIO.Element) => Promise<T>,
    options: {
        maxRetries?: number;
        retryDelay?: number;
        operationName?: string;
    } = {}
): Promise<T> {
    const { maxRetries = 3, retryDelay = 1000, operationName = 'Element operation' } = options;
    const isDeviceFarm = isDeviceFarmEnvironment();
    const actualRetries = isDeviceFarm ? maxRetries + 1 : maxRetries;
    
    let lastError: Error;
    
    for (let attempt = 1; attempt <= actualRetries; attempt++) {
        try {
            if (attempt > 1) {
                const envInfo = isDeviceFarm ? ' (Device Farm)' : '';
                console.log(`🔄 Element retry ${attempt}/${actualRetries}: ${operationName}${envInfo}`);
                await new Promise(resolve => setTimeout(resolve, retryDelay * attempt));
            }
            
            const element = elementGetter();
            await element.waitForExist({ timeout: 5000 });
            await element.waitForDisplayed({ timeout: 5000 });
            
            return await operation(element);
        } catch (error) {
            lastError = error as Error;
            
            if (attempt === actualRetries) {
                const envInfo = isDeviceFarm ? ' (Device Farm)' : '';
                throw new TestError(
                    `${operationName} failed after ${actualRetries} attempts: ${lastError.message}${envInfo}`,
                    { attempts: actualRetries, isDeviceFarm },
                    false
                );
            }
        }
    }
    
    throw lastError!;
}