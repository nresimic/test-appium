export interface DeviceFarmEnvironment {
    isDeviceFarm: boolean;
    deviceName?: string;
    osVersion?: string;
    isSlowerDevice: boolean;
    isOlderOS: boolean;
    timeoutMultiplier: number;
    networkCondition: 'fast' | 'slow' | 'unknown';
}

export function getDeviceFarmEnvironment(): DeviceFarmEnvironment {
    const isDeviceFarm = !!(process.env.DEVICEFARM_DEVICE_UDID || process.env.DEVICEFARM_ENVIRONMENT);
    
    if (!isDeviceFarm) {
        return {
            isDeviceFarm: false,
            isSlowerDevice: false,
            isOlderOS: false,
            timeoutMultiplier: 1,
            networkCondition: 'fast'
        };
    }

    const deviceName = process.env.DEVICEFARM_DEVICE_NAME?.toLowerCase();
    const osVersion = process.env.DEVICEFARM_DEVICE_OS_VERSION;
    const isSlowerDevice = !!(process.env.DEVICEFARM_SLOWER_DEVICE || 
                             deviceName?.includes('s8') || 
                             deviceName?.includes('s9') ||
                             deviceName?.includes('pixel 3'));
    const isOlderOS = !!(process.env.DEVICEFARM_OLDER_OS || 
                        (osVersion && parseInt(osVersion) < 11));
    
    let timeoutMultiplier = parseFloat(process.env.TIMEOUT_MULTIPLIER || '1.8');
    
    const networkCondition = process.env.DEVICEFARM_NETWORK_SLOW ? 'slow' : 
                           process.env.DEVICEFARM_NETWORK_FAST ? 'fast' : 'unknown';

    return {
        isDeviceFarm,
        deviceName,
        osVersion,
        isSlowerDevice,
        isOlderOS,
        timeoutMultiplier,
        networkCondition
    };
}

export function getAdaptiveTimeout(baseTimeout: number, operation: 'ui' | 'network' | 'input' = 'ui'): number {
    const env = getDeviceFarmEnvironment();
    
    if (!env.isDeviceFarm) {
        return baseTimeout;
    }

    let multiplier = env.timeoutMultiplier;
    
    switch (operation) {
        case 'network':
            if (env.networkCondition === 'slow') multiplier *= 2;
            break;
        case 'input':
            if (env.isSlowerDevice) multiplier *= 1.5;
            if (env.isOlderOS) multiplier *= 1.3;
            break;
        case 'ui':
        default:
            if (env.isSlowerDevice) multiplier *= 1.2;
            break;
    }
    
    return Math.round(baseTimeout * multiplier);
}

export function getAdaptivePollingInterval(baseInterval: number = 500): number {
    const env = getDeviceFarmEnvironment();
    
    if (!env.isDeviceFarm) {
        return Math.min(baseInterval, 200); // Faster polling for local
    }
    
    let interval = baseInterval;
    
    if (env.isSlowerDevice) interval *= 1.5;
    if (env.networkCondition === 'slow') interval *= 2;
    
    return Math.round(interval);
}

export function shouldUseEnhancedStability(): boolean {
    const env = getDeviceFarmEnvironment();
    return env.isDeviceFarm && (env.isSlowerDevice || env.isOlderOS);
}

export function getInputDelay(inputType: 'text' | 'tap' | 'scroll' = 'text'): number {
    const env = getDeviceFarmEnvironment();
    
    if (!env.isDeviceFarm) {
        return inputType === 'text' ? 50 : 100;
    }
    
    const baseDelays = {
        text: 150,
        tap: 200,
        scroll: 300
    };
    
    let delay = baseDelays[inputType];
    
    if (env.isSlowerDevice) delay *= 1.5;
    if (env.isOlderOS) delay *= 1.2;
    
    return Math.round(delay);
}

export function logDeviceFarmEnvironment(): void {
    const env = getDeviceFarmEnvironment();
    
    if (env.isDeviceFarm) {
        console.log('🔧 Device Farm Environment Detection:');
        console.log(`   Device: ${env.deviceName || 'Unknown'}`);
        console.log(`   OS Version: ${env.osVersion || 'Unknown'}`);
        console.log(`   Slower Device: ${env.isSlowerDevice}`);
        console.log(`   Older OS: ${env.isOlderOS}`);
        console.log(`   Timeout Multiplier: ${env.timeoutMultiplier}x`);
        console.log(`   Network Condition: ${env.networkCondition}`);
    } else {
        console.log('🏠 Running in local environment');
    }
}