import { step, addAttachment } from '@wdio/allure-reporter';
import { BottomNavigationScreen, MenuScreen, ProfileScreen } from '../../screens';
import { TestUsers } from '../../data';
import { 
    SmartTestIsolation,
    TestIsolationLevel,
    resetAppState,
    ResetStrategy 
} from '../../utils';

describe.skip('Profile Settings', () => {
    const TEST_USER = TestUsers.validUserWithoutBankAcc;
    
    beforeEach(async () => {
        // Profile tests preserve login state
        await SmartTestIsolation.prepareForTest(
            TestIsolationLevel.PRESERVE_LOGIN,
            TEST_USER
        );
        
        // Navigate to profile after smart reset
        await BottomNavigationScreen.tapMenuButton();
        await MenuScreen.tapProfileButton();
        await ProfileScreen.enterPasscode(TEST_USER.passcode);
    });

    it('Should display all profile fields', async () => {   
        await step('Verify basic profile fields', async () => {
            expect(await ProfileScreen.nickname.isDisplayed()).toBe(true);
            expect(await ProfileScreen.firstName.isDisplayed()).toBe(true);
            expect(await ProfileScreen.surname.isDisplayed()).toBe(true);
            expect(await ProfileScreen.phoneNumber.isDisplayed()).toBe(true);
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Profile fields displayed', Buffer.from(screenshot, 'base64'), 'image/png');
        });
        
        await step('Verify additional profile fields', async () => {
            expect(await ProfileScreen.dateOfBirth.isDisplayed()).toBe(true);
            expect(await ProfileScreen.gender.isDisplayed()).toBe(true);
            expect(await ProfileScreen.reasonForUsingVault22.isDisplayed()).toBe(true);
            expect(await ProfileScreen.address.isDisplayed()).toBe(true);
        });
    });

    it('Should update nickname successfully', async () => {
        await step('Tap on nickname field', async () => {
            await ProfileScreen.nickname.click();
        });
        
        await step('Enter new nickname', async () => {
            const nicknameInput = await ProfileScreen.nicknameInput;
            await nicknameInput.clearValue();
            await nicknameInput.setValue('TestNickname');
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Nickname entered', Buffer.from(screenshot, 'base64'), 'image/png');
        });
        
        await step('Save nickname update', async () => {
            await ProfileScreen.updateProfileInfoButton.click();
            
            await browser.pause(2000);
            
            const nicknameText = await ProfileScreen.nickname.getText();
            expect(nicknameText).toContain('TestNickname');
        });
    });

    it('Should update first name and surname', async () => {
        await step('Update first name', async () => {
            await ProfileScreen.firstName.click();
            
            const firstNameInput = await ProfileScreen.nicknameInput;
            await firstNameInput.clearValue();
            await firstNameInput.setValue('John');
            await ProfileScreen.updateProfileInfoButton.click();
            
            await browser.pause(2000);
        });
        
        await step('Update surname', async () => {
            await ProfileScreen.surname.click();
            
            const surnameInput = await ProfileScreen.nicknameInput;
            await surnameInput.clearValue();
            await surnameInput.setValue('Doe');
            await ProfileScreen.updateProfileInfoButton.click();
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Name updated', Buffer.from(screenshot, 'base64'), 'image/png');
            
            await browser.pause(2000);
        });
    });

    it('Should update date of birth', async () => {
        await step('Select date of birth', async () => {
            await ProfileScreen.selectDateOfBirth('1990');
            
            await browser.pause(2000);
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Date of birth updated', Buffer.from(screenshot, 'base64'), 'image/png');
        });
    });

    it('Should update gender preference', async () => {
        await step('Select gender', async () => {
            await ProfileScreen.selectGender('Male');
            
            await browser.pause(2000);
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Gender updated', Buffer.from(screenshot, 'base64'), 'image/png');
        });
    });

    // it('Should update reason for using Vault22', async () => {
    //     addDescription('Update reason for using the app', 'text');
    //     addSeverity(Severity.MINOR);
    //     addOwner('Mobile QA Team');
        
    //     await step('Tap reason field', async () => {
    //         await ProfileScreen.reasonForUsingVault22.click();
    //     });
        
    //     await step('Select reason option', async () => {
    //         const reasonOption = await $('~Save for the future');
    //         if (await reasonOption.isExisting()) {
    //             await reasonOption.click();
    //         } else {
    //             const alternativeOption = await $('~Invest my money');
    //             await alternativeOption.click();
    //         }
            
    //         await ProfileScreen.updateProfileInfoButton.click();
            
    //         const screenshot = await browser.takeScreenshot();
    //         await addAttachment('Reason updated', Buffer.from(screenshot, 'base64'), 'image/png');
    //     });
    // });

    it('Should handle cancel action correctly', async () => {
        await step('Start editing nickname', async () => {
            await ProfileScreen.nickname.click();
            
            const nicknameInput = await ProfileScreen.nicknameInput;
            await nicknameInput.clearValue();
            await nicknameInput.setValue('TempNickname');
        });
        
        await step('Cancel the changes', async () => {
            await ProfileScreen.cancelButton.click();
            
            await browser.pause(2000);
            
            const nicknameText = await ProfileScreen.nickname.getText();
            expect(nicknameText).not.toContain('TempNickname');
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Changes cancelled', Buffer.from(screenshot, 'base64'), 'image/png');
        });
    });

    it('Should persist profile changes after app restart', async () => {
        let savedNickname: string;
        let savedFirstName: string;
        
        await step('Note current profile values', async () => {
            const nicknameText = await ProfileScreen.nickname.getText();
            const firstNameText = await ProfileScreen.firstName.getText();
            
            savedNickname = nicknameText;
            savedFirstName = firstNameText;
        });
        
        await step('Restart app to verify persistence', async () => {
            // Use MEDIUM reset - restarts app but keeps data/login (much faster than reloadSession)
            await resetAppState(ResetStrategy.MEDIUM);
        });
        
        await step('Navigate back to profile', async () => {
            // No need to login again - user should still be logged in after MEDIUM reset
            await BottomNavigationScreen.tapMenuButton();
            await MenuScreen.tapProfileButton();
            await ProfileScreen.enterPasscode(TEST_USER.passcode);
        });
        
        await step('Verify values persisted', async () => {
            const nicknameText = await ProfileScreen.nickname.getText();
            const firstNameText = await ProfileScreen.firstName.getText();
            
            expect(nicknameText).toBe(savedNickname);
            expect(firstNameText).toBe(savedFirstName);
            
            const screenshot = await browser.takeScreenshot();
            await addAttachment('Profile values persisted', Buffer.from(screenshot, 'base64'), 'image/png');
        });
    });

    // Additional test scenarios that could be implemented:
    // - Update avatar (requires camera/gallery permissions)
    // - Update address manually
    // - Update address automatically (requires location permissions)
    // - Verify phone number cannot be edited
    // - Test field validation (e.g., invalid characters in name)
    // - Test maximum length limits for text fields
    // - Verify biometric authentication if enabled
});