import { RegistrationFlow } from '../../flows';
import { DashboardScreen } from '../../screens';
import { TestUsers } from '../../data';
import { step } from '@wdio/allure-reporter';
import { 
    attachScreenshot,
    SmartTestIsolation,
    TestIsolationLevel 
} from '../../utils';

describe('Registration Flow', () => {
    beforeEach(async () => {
        // Registration tests need full clean state
        await SmartTestIsolation.prepareForTest(TestIsolationLevel.FULL_CLEAN);
    });    
    it('Should register a new user successfully', async () => {
        const newUser = TestUsers.generateNewUser();
        
        await step('Register new user and skip bank linking', async () => {
            await RegistrationFlow.registerNewUserWithoutAddingBankAccount(newUser);
            
            await attachScreenshot('New user registered'); 
            
            await DashboardScreen.validateDashboardButtons();
        });
        
    });
});