import { verifyElementDisplayed } from '../../utils/wait.utils';
import { scrollToElementWithDirection, SwipeDirection } from '../../utils/gesture.utils';
import BaseScreen from '../base.screen';

class ProfileScreen extends BaseScreen {
    // TODO: Add element selectors when accessibility IDs are available

    get passcodeInput() {
        return this.getElement({
            android: 'android.widget.EditText',
            ios: '~|'
        });
    }

    get nickname() {
        return this.getElement('~Nickname');
    }

    get firstName() {
        return this.getElement('~First name');
    }

    get surname() {
        return this.getElement('~Surname');
    }

    get phoneNumber() {
        return this.getElement('~Phone number');
    }

    get dateOfBirth() {
        return this.getElement('~Date of birth');
    }

    get gender() {
        return this.getElement('~Gender');
    }

    get reasonForUsingVault22() {
        return this.getElement('~Reason for using Vault22');
    }
    
    get address() {
        return this.getElement('~Address');
    }

    get nicknameInput() {
        return this.getElement({
            android: 'android.widget.EditText',
            ios: 'XCUIElementTypeTextField'
        });
    }

    get updateProfileInfoButton() {
        return this.getElement('~Update');
    }

    get cancelButton() {
        return this.getElement('~Cancel');
    }

    async enterPasscode(passcode: string) {
        const passcodeField = await this.passcodeInput;
        await verifyElementDisplayed(passcodeField);
        await passcodeField.click();
        await passcodeField.clearValue();
        await passcodeField.setValue(passcode);
    }

    async selectDateOfBirth(year: string) {
        await this.dateOfBirth.click();
        
        if (this.isAndroid) {
            const selector = `android=new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().description("${year}"))`;
            const yearElement = await $(selector);
            await yearElement.click();
        } else {
            const targetYear = parseInt(year);
            const currentYear = new Date().getFullYear();
            
            const direction = targetYear < currentYear ? SwipeDirection.UP : SwipeDirection.DOWN;
            
            await scrollToElementWithDirection(`~${year}`, direction, 10);
            await $(`~${year}`).click();
        }
        
        await this.updateProfileInfoButton.click();
    }

    async selectGender(gender: 'Male' | 'Female' | 'Other' | 'Prefer not to say') {
        await this.gender.click();
        
        // Wait for the gender option to be clickable
        const genderOption = await $(`~${gender}`);
        await genderOption.waitForDisplayed({ timeout: 5000 });
        await genderOption.click();
        
        await this.updateProfileInfoButton.click();
    }
    
    // Profile fields:
    // - Avatar
    // - Nickname
    // - First name
    // - Last name  
    // - Date of birth
    // - Reason for using Vault22
    // - Address (manual/automatic)
    
    // Methods for updating profile
    
    // Verification methods
}

export default new ProfileScreen();