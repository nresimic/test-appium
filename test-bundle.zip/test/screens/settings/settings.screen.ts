import BaseScreen from '../base.screen';

/**
 * Settings screen
 * Accessed from Menu > Settings
 */
class SettingsScreen extends BaseScreen {
    // TODO: Add element selectors when accessibility IDs are available

    get profileButton() {
        return this.getElement('~Profile\nYour personal information');
    }

    get investmentStyleButton() {
        return this.getElement('~Investment Style\nSet investment experience and risk comfort');
    }

    get recurringPaymentsButton() {
        return this.getElement('~Recurring payments\nInstallments with active recurring payments');
    }

    get currencyButton() {
        return this.getElement('~Currency\nChoose preferred display currency');
    }

    get securityButton() {
        return this.getElement('~Security\nUpdate passcode and enable protection');
    }

    get notificationsButton() {
        return this.getElement('~Notifications\nManage alert preferences');
    }

    get languageButton() {
        return this.getElement('~Language\nChange app language');
    }

    get themeButton() {
        return this.getElement('~Theme\nSwitch between light and dark mode');
    }

    get accountPreferencesButton() {
        return this.getElement('~Account preferences\nAdjust your account settings');
    }

    get deactivatedAccountsButton() {
        return this.getElement('~Deactivated accounts\nSee all inactive accounts');
    }

    
    // Settings options (actual from screenshot):
    // - Profile (Your personal information)
    // - Investment Style (Set investment experience and risk comfort)
    // - Recurring payments (Installments with active recurring payments)
    // - Currency (Choose preferred display currency)
    // - Security (Update passcode and enable protection)
    // - Notifications (Manage alert preferences)
    // - Language (Change app language)
    // - Theme (Switch between light and dark mode)
    // - Account preferences (Adjust your account settings)
    // - Deactivated accounts (See all inactive accounts)

    async openProfile() {
        
    }
    
    async openCurrency() {
        await this.currencyButton.click();
    }
    
    async openSecurity() {
        // Tap Security
    }
    
    async openLanguage() {
        // Tap Language
    }
    
    async openTheme() {
        // Tap Theme
    }
    
    // Verification methods
}

export default new SettingsScreen();